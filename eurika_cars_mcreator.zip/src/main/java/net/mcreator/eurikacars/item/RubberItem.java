package net.mcreator.eurikacars.item;

import net.minecraft.world.item.Item;

public class RubberItem extends Item {
	public RubberItem() {
		super(new Item.Properties());
	}
}