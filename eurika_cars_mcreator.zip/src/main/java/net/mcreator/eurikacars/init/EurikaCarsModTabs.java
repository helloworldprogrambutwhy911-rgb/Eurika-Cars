/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eurikacars.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.eurikacars.EurikaCarsMod;

public class EurikaCarsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EurikaCarsMod.MODID);
	public static final RegistryObject<CreativeModeTab> EUREKA_CARS = REGISTRY.register("eureka_cars",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.eurika_cars.eureka_cars")).icon(() -> new ItemStack(EurikaCarsModBlocks.RUBBER_WHEEL.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EurikaCarsModBlocks.RUBBER_WHEEL.get().asItem());
				tabData.accept(EurikaCarsModItems.RUBBER.get());
				tabData.accept(EurikaCarsModBlocks.BLOCKOF_RUBBER.get().asItem());
				tabData.accept(EurikaCarsModBlocks.RUBBER_ORE_BLOCK.get().asItem());
				tabData.accept(EurikaCarsModBlocks.RED_IRON_HULL.get().asItem());
				tabData.accept(EurikaCarsModBlocks.ORANGE_IRON_HULL.get().asItem());
				tabData.accept(EurikaCarsModBlocks.YELLOW_IRON_HULL.get().asItem());
				tabData.accept(EurikaCarsModBlocks.GREEN_IRON_HULL.get().asItem());
				tabData.accept(EurikaCarsModBlocks.BLUE_IRON_HULL.get().asItem());
				tabData.accept(EurikaCarsModBlocks.CAR_BASE.get().asItem());
			}).build());
}