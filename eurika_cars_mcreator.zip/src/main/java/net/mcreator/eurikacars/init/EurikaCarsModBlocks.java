/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eurikacars.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.eurikacars.block.*;
import net.mcreator.eurikacars.EurikaCarsMod;

public class EurikaCarsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EurikaCarsMod.MODID);
	public static final RegistryObject<Block> RUBBER_WHEEL;
	public static final RegistryObject<Block> BLOCKOF_RUBBER;
	public static final RegistryObject<Block> RUBBER_ORE_BLOCK;
	public static final RegistryObject<Block> RED_IRON_HULL;
	public static final RegistryObject<Block> ORANGE_IRON_HULL;
	public static final RegistryObject<Block> YELLOW_IRON_HULL;
	public static final RegistryObject<Block> GREEN_IRON_HULL;
	public static final RegistryObject<Block> BLUE_IRON_HULL;
	public static final RegistryObject<Block> CAR_BASE;
	static {
		RUBBER_WHEEL = REGISTRY.register("rubber_wheel", RubberWheelBlock::new);
		BLOCKOF_RUBBER = REGISTRY.register("blockof_rubber", BlockofRubberBlock::new);
		RUBBER_ORE_BLOCK = REGISTRY.register("rubber_ore_block", RubberOreBlockBlock::new);
		RED_IRON_HULL = REGISTRY.register("red_iron_hull", RedIronHullBlock::new);
		ORANGE_IRON_HULL = REGISTRY.register("orange_iron_hull", OrangeIronHullBlock::new);
		YELLOW_IRON_HULL = REGISTRY.register("yellow_iron_hull", YellowIronHullBlock::new);
		GREEN_IRON_HULL = REGISTRY.register("green_iron_hull", GreenIronHullBlock::new);
		BLUE_IRON_HULL = REGISTRY.register("blue_iron_hull", BlueIronHullBlock::new);
		CAR_BASE = REGISTRY.register("car_base", CarBaseBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}