/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eurikacars.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.eurikacars.item.RubberItem;
import net.mcreator.eurikacars.EurikaCarsMod;

public class EurikaCarsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EurikaCarsMod.MODID);
	public static final RegistryObject<Item> RUBBER_WHEEL;
	public static final RegistryObject<Item> RUBBER;
	public static final RegistryObject<Item> BLOCKOF_RUBBER;
	public static final RegistryObject<Item> RUBBER_ORE_BLOCK;
	public static final RegistryObject<Item> RED_IRON_HULL;
	public static final RegistryObject<Item> ORANGE_IRON_HULL;
	public static final RegistryObject<Item> YELLOW_IRON_HULL;
	public static final RegistryObject<Item> GREEN_IRON_HULL;
	public static final RegistryObject<Item> BLUE_IRON_HULL;
	public static final RegistryObject<Item> CAR_BASE;
	static {
		RUBBER_WHEEL = block(EurikaCarsModBlocks.RUBBER_WHEEL);
		RUBBER = REGISTRY.register("rubber", RubberItem::new);
		BLOCKOF_RUBBER = block(EurikaCarsModBlocks.BLOCKOF_RUBBER);
		RUBBER_ORE_BLOCK = block(EurikaCarsModBlocks.RUBBER_ORE_BLOCK);
		RED_IRON_HULL = block(EurikaCarsModBlocks.RED_IRON_HULL);
		ORANGE_IRON_HULL = block(EurikaCarsModBlocks.ORANGE_IRON_HULL);
		YELLOW_IRON_HULL = block(EurikaCarsModBlocks.YELLOW_IRON_HULL);
		GREEN_IRON_HULL = block(EurikaCarsModBlocks.GREEN_IRON_HULL);
		BLUE_IRON_HULL = block(EurikaCarsModBlocks.BLUE_IRON_HULL);
		CAR_BASE = block(EurikaCarsModBlocks.CAR_BASE);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}